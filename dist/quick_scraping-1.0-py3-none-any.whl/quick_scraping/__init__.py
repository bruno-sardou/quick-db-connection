"""Quick Scraping - Uma biblioteca para web scraping combinando Selenium e BeautifulSoup."""

__version__ = "0.1.0"
